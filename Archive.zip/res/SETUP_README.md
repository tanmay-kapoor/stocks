# Setting up the project

Please follow the steps below to run the program:

1. cd to the project directory.
2. open terminal and print `cd res` and press ENTER. you should see a file with .jar extension. 
   This is the file that you'll be using to interact with the program.
3. type `java -jar ass4.jar` to run the program.
4. After completing all the previous steps successfully you should see a menu printed 
   in the command line interface. Please refer to the `README.md` to know the features provided
   by the program.

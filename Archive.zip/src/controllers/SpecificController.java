package controllers;

public interface SpecificController {
  void start();
}

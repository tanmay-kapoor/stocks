package controllers;

public enum FileType {
  Portfolio, LogFile, CostBasisFile
}

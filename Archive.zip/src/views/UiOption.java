package views;

public interface UiOption {
  char getUiOption();
}

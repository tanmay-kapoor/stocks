package views;

/**
 * Interface that mentions all methods that are to be implemented in classes that implement
 * this class.
 */
public interface MainMenu {
  char getPortfolioType();
}

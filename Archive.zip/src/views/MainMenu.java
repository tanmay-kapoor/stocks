package views;

public interface MainMenu {
  char getPortfolioType();
}

package views;

/**
 * Enum to help represent the type of chart to display on screen.
 */
public enum ChartType {
  BAR_CHART, LINE_CHART
}

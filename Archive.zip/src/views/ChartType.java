package views;

public enum ChartType {
  BAR_CHART, LINE_CHART
}

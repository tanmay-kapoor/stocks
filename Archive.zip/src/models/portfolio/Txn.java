package models.portfolio;

/**
 * Mentions the type of transactions that can be performed in the portfolio
 */
public enum Txn {
  Buy, Sell
}

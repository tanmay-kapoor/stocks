package models.portfolio;

/**
 * Lists the type of compositions that can be requested by the client.
 */
public enum Composition {
  Contents, Weightage
}

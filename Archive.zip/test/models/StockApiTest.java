package models;

import org.junit.Test;

public class StockApiTest {

  @Test
  public void getShareDetails() {

  }
}
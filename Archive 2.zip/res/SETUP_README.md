#  Project setup guide

Please follow the steps below to run the program:

1. Open the project root directory in the in terminal. 
   

2. type `cd res` and press ENTER. you should see a file with .jar extension in this directory. 
   This is the file that you'll be using to interact with the program.


3. type `java -jar ass4.jar` to run the program.
  

4. After completing all the previous steps successfully you should see a menu printed 
   in the command line interface. Please refer to the `README.md` to know the features provided
   by the program.
